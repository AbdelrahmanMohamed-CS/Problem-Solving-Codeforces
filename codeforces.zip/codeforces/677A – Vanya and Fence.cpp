#include <iostream>
using namespace std;

int main() {
    int n, h;
    cin >> n >> h;

    int width = 0, x;
    for(int i = 0; i < n; i++) {
        cin >> x;
        if(x > h)
            width += 2;
        else
            width += 1;
    }

    cout << width << endl;
    return 0;
}
