#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;
    string s;
    cin >> s;

    int A = 0, D = 0;
    for(char c : s) {
        if(c == 'A')
            A++;
        else
            D++;
    }

    if(A > D)
        cout << "Anton\n";
    else if(D > A)
        cout << "Danik\n";
    else
        cout << "Friendship\n";

    return 0;
}
