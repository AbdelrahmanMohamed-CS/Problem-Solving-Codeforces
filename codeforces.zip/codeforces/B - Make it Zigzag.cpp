#include <bits/stdc++.h>
using namespace std;

long long solvePattern(vector<long long> a, bool oddHigh) {
    int n = a.size();
    long long cost = 0;

    for (int i = 0; i < n; i++) {
        bool shouldBeHigh = ((i % 2 == 0) == oddHigh);

        if (!shouldBeHigh) {
            long long mn = LLONG_MAX;
            if (i - 1 >= 0) mn = min(mn, a[i - 1]);
            if (i + 1 < n) mn = min(mn, a[i + 1]);

            if (a[i] >= mn) {
                long long newVal = mn - 1;
                cost += a[i] - newVal;
                a[i] = newVal;   
            }
        }
    }

    return cost;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t; 
    cin >> t;

    while (t--) {
        int n;
        cin >> n;
        vector<long long> a(n);
        for (int i = 0; i < n; i++) cin >> a[i];

        long long r1 = solvePattern(a, true);
        long long r2 = solvePattern(a, false);

        cout << min(r1, r2) << "\n";
    }
    return 0;
}
